var todoViewInstance = new TodoView();

// Uitwerking Opdracht 2, zonder onLoad eventlistener (javascript in template wordt onderaan de pagina geladen)
todoViewInstance.renderTodos(todos);
todoViewInstance.renderGebruikers(gebruikers);

