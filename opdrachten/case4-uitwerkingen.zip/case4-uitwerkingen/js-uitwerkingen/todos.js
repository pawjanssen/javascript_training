var todos = [
    {
        "id": 1,
        "titel": "Afmaken opdracht 1",
        "created": "22-11-2013",
        "priority": "high"
    },
    {
        "id": 2,
        "titel": "Afmaken opdracht 2",
        "created": "22-11-2013",
        "priority": "low"
    }
];