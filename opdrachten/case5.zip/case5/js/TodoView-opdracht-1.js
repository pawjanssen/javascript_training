function TodoView() {
}

TodoView.prototype.todosDraggable = function () {
    // TODO Maak de todo's draggable en zorg de ze kunnen wat in de todo zelf staat.
};

TodoView.prototype.gebruikersDroppable = function () {
    // TODO de gebruikers lijst droppable maken, laat met een console log zien op welke user je de todo sleept.
};