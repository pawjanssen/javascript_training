function TodoStorage() {
}

TodoStorage.prototype.getBaseUrl = function() {
    return "/gebruikers/1/todos";
};
