var todoViewInstance = new TodoView();

todoViewInstance.renderTemplate();