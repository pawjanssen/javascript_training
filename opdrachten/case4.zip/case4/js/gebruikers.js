var gebruiker1 = new Object();
gebruiker1.id = 1;
gebruiker1.naam = "J. Script";
gebruiker1.gebruikersnaam = "jscript";

var gebruiker2 = new Object();
gebruiker2.id = 2;
gebruiker2.naam = "C. Scherp";
gebruiker2.gebruikersnaam = "cscherp";

var gebruiker3 = new Object();
gebruiker3.id = 3;
gebruiker3.naam = "S. Cala";
gebruiker3.gebruikersnaam = "scala";

var gebruikers = new Array(gebruiker1, gebruiker2, gebruiker3);