var todoViewInstance = new TodoView();

todoViewInstance.todosDraggable();
todoViewInstance.gebruikersDroppable();
todoViewInstance.clickhandlersTodoToevoegen()