function TodoView() {
}

TodoView.prototype.todosDraggable = function () {
    $("div.todoDrag").draggable({         });

    $("div.todoDragInContainer").draggable({ revert: true ,
        containment: ".dragContainer",
        helper: "clone"});
};

TodoView.prototype.gebruikersDroppable = function () {
    $("#gebruikerslijst li").droppable({
        hoverClass: "todoOverGebruiker",
        drop: function() {
            console.log($(this).find(".naam").text());
        }
    });
};