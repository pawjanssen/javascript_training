var todoViewInstance = new TodoView();

todoViewInstance.renderTodos(todos);
todoViewInstance.renderGebruikers(gebruikers);