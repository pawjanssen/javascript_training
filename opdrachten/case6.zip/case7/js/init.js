var todoViewInstance = new TodoView();
var todoStorageInstance = new TodoStorage();

todoViewInstance.renderTemplate();