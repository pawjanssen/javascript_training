function TodoView() {
}

TodoView.prototype.renderTemplate = function() {

};

