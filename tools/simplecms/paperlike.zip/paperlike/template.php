<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }
/****************************************************
*
* @File: 			template.php
* @Package:		GetSimple
* @Action:		Distinctive theme for the GetSimple 3.0
*
*****************************************************/
?>


<!DOCTYPE html>
<!--
Design by Free CSS Templates
http://www.freecsstemplates.org
Released for free under a Creative Commons Attribution 2.5 License

Name       : Paperlike     
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20111010

-->
<html>
<head>
<title><?php get_page_clean_title(); ?> - <?php get_site_name(); ?></title>
    <?php get_header(); ?>

<link href="<?php get_theme_url(); ?>/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
<div id="wrapper">
	<div id="header-wrapper">
		<div id="header">
			<div id="logo">
				<h1><a href="#"><?php get_site_name(); ?> </a></h1>
				<p><?php get_component('tagline'); ?></p>
			</div>
			<div id="menu">
				<ul>
					<?php get_navigation(return_page_slug()); ?>
				</ul>
			</div>
		</div>
	</div>
	<!-- end #header -->
	<div id="page">
		<div id="content">
			<div class="post">
				<h2 class="title"><a href="#"><?php get_page_title(); ?> </a></h2>
				<p class="meta"><span class="author"><a href="#"><?php get_component('author'); ?></a></span> <span class="date"><?php get_page_date('F jS, Y'); ?></span>&nbsp;</p>
				<div class="entry">
					<?php get_page_content(); ?>
				</div>
			</div>
			
			
			
		</div>
		<!-- end #content -->
		<div id="sidebar">
			<ul>
				<li> 
					<br/><!-- empty space-->
				</li>
				
				
				<li>
					<?php get_component('sidebar'); ?>
				</li>
				<li>
					<?php get_component('sidebar2'); ?>
				</li>
			</ul>
		</div>
		<!-- end #sidebar -->
		<div style="clear: both;">&nbsp;</div>
	</div>
	<!-- end #page -->
</div>
<div id="footer">
	<p>Copyright (c) <?php get_site_name(); ?> | Original Design by <a href="http://www.freecsstemplates.org/"> CSS Templates</a>   |    <?php get_site_credits(); ?></p>
</div>
<!-- end #footer -->
</body>
</html>
