var todo1 = new Object();
todo1.id = 1;
todo1.titel = "Afmaken opdracht 1";
todo1.created = "22-11-2013";
todo1.priority = "high";

var todo2 = new Object();
todo2.id = 2;
todo2.titel = "Afmaken opdracht 2";
todo2.created = "22-11-2013";
todo2.priority = "low";

var todos = new Array(todo1, todo2);